/*
 * ClientFTP.c
 */
#include "csapp.h"
#include "readcmd.h"

#define MAX_NAME_LEN 64
#define BUFFER_SIZE 16

int main(int argc, char **argv)
{
    int clientfd, port;
    char *host, buf[MAXLINE];
    rio_t rio;

    if (argc != 3) {
        fprintf(stderr, "usage: %s <host> <port>\n", argv[0]);
        exit(0);
    }
    host = argv[1];
    port = atoi(argv[2]);

    /*
     * Note that the 'host' can be a name or an IP address.
     * If necessary, Open_clientfd will perform the name resolution
     * to obtain the IP address.
     */
    clientfd = Open_clientfd(host, port);

    /*
     * At this stage, the connection is established between the client
     * and the server OS ... but it is possible that the server application
     * has not yet called "Accept" for this connection
     */
    printf("client connected to server OS\n");

    //Initialisation de rio
    Rio_readinitb(&rio, clientfd);

    while (1) {
        //Lecture de la commande
        struct cmdline *l;
        printf("FTP > ");
        l = readcmd();
        l->err = NULL;

        //Commande get
        if (strcmp("get", l->seq[0][0]) == 0) {
            if (l->seq[0][1] == NULL) {
                printf("usage get <filename>\n");
            } else {
                //On envoie la commande
                //printf("taille : %d\tmot : %s\n",sizeof(l->seq[0][0]),l->seq[0][0]);
                Rio_writen(clientfd, l->seq[0][0], MAX_NAME_LEN);
                //Et son argument
                //printf("taille : %d\tmot : %s\n",sizeof(l->seq[0][1]),l->seq[0][1]);
                Rio_writen(clientfd, l->seq[0][1], MAX_NAME_LEN);

                FILE * sortie = fopen("sortieClient","w+");

                //Lecture de la reponse
                while(Rio_readnb(&rio, buf, BUFFER_SIZE) > 0) {
                  printf("BUF = _%s_\n",buf);
                    if (strcmp(buf,"Fin fichier") == 0) {
                      break;
                    } else {
                      Fputs(buf, sortie);
                    }
                }

                fclose(sortie);

                printf("\nFin du get\n\n");
            }


        //Commande bye
        } else if (strcmp("bye", l->seq[0][0]) == 0) {
            Rio_writen(clientfd, l->seq[0][0], MAX_NAME_LEN);
            break;


        //Autre
        } else {
            printf("Commande inconue\n");
        }

    }

    //Fermeture du client
    Close(clientfd);
    exit(0);
}
