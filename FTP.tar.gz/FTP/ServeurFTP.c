#include "ServeurFTP.h"

#define MAX_NAME_LEN 64
#define BUFFER_SIZE 1
#define NBPROC 3
#define PORT 2121


pid_t pids[NBPROC];
pid_t pidPere;

void handlerSigChild(int sig) {
    pid_t pid;
    while ((pid = waitpid(-1, NULL, WNOHANG)) > 0);
}

void handlerSigInt(int sig) {
    if (pidPere == getpid()) {
        for (int i =0; i < NBPROC; i++) {
            kill(pids[i],SIGINT);
        }
    }
    exit(0);
}

int traiteConnection(int connfd) {
    char buf[MAX_NAME_LEN];
    char commande[MAX_NAME_LEN];
    char arg[MAX_NAME_LEN];
    size_t n;
    rio_t rio;

    Rio_readinitb(&rio, connfd);

    //Recupereration de la commande
    Rio_readnb(&rio, commande, MAX_NAME_LEN);
    printf("Server received command : _%s_\n", commande);
    //Recuperation de(s) argument(s)
    Rio_readnb(&rio, arg, MAX_NAME_LEN);
    printf("with arg(s) : _%s_\n", arg);

    //Commande get
    if (strcmp(commande,"get") == 0) {
        char * filename = malloc(strlen(arg));
        strcpy(filename,arg);
        printf("filename : _%s_\n",filename);

        //Ouverture du fichier
        int fdin = Open(filename, O_RDONLY, 0);

        //Ecriture du fichier
        int octets = 0;
        while ( (n = Read(fdin, buf, BUFFER_SIZE)) > 0) {
            octets+=n;
            Rio_writen(connfd, buf, n);
        }
        printf("Fichier %s correctement envoye (%d octets envoyes)\n", filename, octets);

        fsync(connfd);

        Close(fdin);
        free(filename);


    //Commande bye
    } else if(strcmp(commande,"bye") == 0) {
        return 0;


    //Autre
    } else {
        strncpy(buf, "Commande inconue par le serveur", MAX_NAME_LEN);
        Rio_writen(connfd, buf, MAX_NAME_LEN);
        printf("%s\n",buf);
    }


    return 1;
}

void connectionTraitant(int listenfd, struct sockaddr_in clientaddr, socklen_t clientlen, char * client_hostname, char * client_ip_string) {
    int connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);

    /* determine the name of the client */
    Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAX_NAME_LEN, 0, 0, 0);

    /* determine the textual representation of the client's IP address */
    Inet_ntop(AF_INET, &clientaddr.sin_addr, client_ip_string, INET_ADDRSTRLEN);

    printf("server connected to %s (%s) with child %d\n", client_hostname,client_ip_string,getpid());

    while(traiteConnection(connfd));
    //traiteConnection(connfd);

    printf("Server deconnected from %s (%s) with child %d\n\n", client_hostname,client_ip_string,getpid());
    Close(connfd);
}

/*
 * Note that this code only works with IPv4 addresses
 * (IPv6 is not supported)
 */
int main()
{
    /* Gestion des signaux */
    Signal(SIGCHLD, handlerSigChild);
    Signal(SIGINT, handlerSigInt);
    pidPere = getpid();


    int listenfd;
    socklen_t clientlen;
    struct sockaddr_in clientaddr;
    char client_ip_string[INET_ADDRSTRLEN];
    char client_hostname[MAX_NAME_LEN];
    pid_t pid;


    clientlen = (socklen_t)sizeof(clientaddr);

    listenfd = Open_listenfd(PORT);

    for (int i = 0; i < NBPROC; i++) {  //Creation de la pool de processus
        if ((pid = Fork()) == 0) {      //Ce seront les fils qui vont trater les connections
            while(1) {
                connectionTraitant(listenfd, clientaddr, clientlen, client_hostname, client_ip_string);
            }
        } else {
            pids[i] = pid;
        }
    }


    for (int i = 0; i < NBPROC; i++) {
        wait(NULL);
    }

    exit(0);
}
